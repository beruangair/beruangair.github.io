<?php $__env->startSection('title', 'Dashboard'); ?>


<?php $__env->startSection('meta'); ?>
  ##parent-placeholder-cb030491157b26a570b6ee91e5b068d99c3b72f6##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('icon'); ?>
  ##parent-placeholder-f8995ba5891b07e328c60d6bd6c10159878c5a13##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
  ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('topbar'); ?>
  ##parent-placeholder-3c92cc16927acc90a786c4846f5ebef1866fddf8##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('leftbar'); ?>
  ##parent-placeholder-8f33317698a50182f7aaed67b91c69957eec8cb7##
  <?php $__env->startSection('dashboard', 'active'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
  ##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
  ##parent-placeholder-b6e13ad53d8ec41b034c49f131c64e99cf25207a##
  <script type="text/javascript">
      jQuery(document).ready(function($) {
          $('.counter').counterUp({
              delay: 100,
              time: 1200
          });
          $(".knob").knob();
      });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.components.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>