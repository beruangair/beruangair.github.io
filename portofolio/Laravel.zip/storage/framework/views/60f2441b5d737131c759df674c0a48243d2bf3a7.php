<?php $__env->startSection('title', 'Update Logo'); ?>


<?php $__env->startSection('meta'); ?>
  ##parent-placeholder-cb030491157b26a570b6ee91e5b068d99c3b72f6##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('icon'); ?>
  ##parent-placeholder-f8995ba5891b07e328c60d6bd6c10159878c5a13##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
  ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
  <link rel="stylesheet" href="<?php echo e(URL::asset('css/admin/dropzone.css')); ?>"> <!-- Dropzone -->
  <link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet"> <!-- Font QuickSand -->
  <style>
  .logo-result {
    font-family: 'Quicksand', sans-serif;
    color: #000;
    font-size: 40px;
    font-weight: 500;
  }
  </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('topbar'); ?>
  ##parent-placeholder-3c92cc16927acc90a786c4846f5ebef1866fddf8##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('leftbar'); ?>
  ##parent-placeholder-8f33317698a50182f7aaed67b91c69957eec8cb7##
  <?php $__env->startSection('logo', 'active'); ?>
  <?php $__env->startSection('header-menu', 'subdrop'); ?>
  <?php $__env->startSection('header-menu-show', 'display: block'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
  <div class="content-page">
    <!-- Start content -->
    <div class="content">
      <div class="container-fluid">

        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title">Social Media</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="#">Header</a></li>
                    <li class="breadcrumb-item active">Logo</li>
                </ol>

            </div>
        </div>

        <div class="row">
          <div class="col-md-12">
            <div class="card-box table-responsive">
              <div class="row">
                <div class="col-sm-12">
                  <?php echo e(Form::open(array('url' => '/updateLogo','method' => 'post'))); ?>

                  <div class="row">
                    <div class="col-sm-5">
                        <div class="form-group">
                          <label>Logo Label</label>
                          <div class="input-group">
                            <input type="hidden" name="id_logo" value="<?php echo e($logo[0]->id_logo); ?>">
                            <input type="text" name="logo" class="form-control" id="logoInput" required="" value="<?php echo e($logo[0]->logo); ?>" placeholder="Your Logo Label">
                          </div>
                        </div>
                    </div>
                    <div class="col-sm-1">
                    </div>
                    <div class="col-sm-6">
                      <span class="logo-preview">
                        <label>This is Your Logo Look Like</label>
                        <div class="logo-result"><?php echo e($logo[0]->logo); ?></div>
                      </span>
                    </div>
                  </div>
                  <div class="form-group text-right m-t-20">
                    <button class="btn btn-primary waves-effect waves-light" type="submit">
                        Submit
                    </button>
                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                        Cancel
                    </button>
                  </div>
                  <?php echo e(Form::close()); ?>

                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- end row -->
      </div> <!-- container -->
    </div> <!-- content -->

    <footer class="footer text-right">
        &copy; 2016 - 2017. All rights reserved.
    </footer>
  </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
  ##parent-placeholder-b6e13ad53d8ec41b034c49f131c64e99cf25207a##
  <script type="text/javascript">
    /* Upload Preview */
    function preview(input) {
      if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) { $('#img').attr('src', e.target.result);  }
        reader.readAsDataURL(input.files[0]);
      }
    }
    $("#upload").change(function(){
      $("#img").css({top: 0, left: 0});
        preview(this);
        $("#img").draggable({ containment: 'parent',scroll: false });
    });
    /* Detect Data Change From Input Field */
    $("#logoInput").on("input", function(e) {
      var input = $(this);
      var val = input.val();
      if (input.data("lastval") != val) {
        input.data("lastval", val);
        $( ".logo-result" ).text(val);
      }
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.components/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>