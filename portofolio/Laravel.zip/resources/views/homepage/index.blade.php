@extends('homepage.components.layout')

@section('title', 'Arif Lutfhansah')

{{-- Meta --}}
@section('meta')
  @parent
@endsection

{{-- Icon --}}
@section('icon')
  @parent
@endsection

{{-- CSS --}}
@section('css')
  @parent
@endsection

{{-- Header --}}
@section('header')
  @parent
@endsection

{{-- Navigation Mobile --}}
@section('navigation_mobile')
  @parent
@endsection

{{-- Main --}}
@section('main')
  @parent
@endsection

{{-- Footer --}}
@section('footer')
  @parent
@endsection

{{-- Javascript --}}
@section('javascript')
  @parent
@endsection