<?php $__env->startSection('title', 'Arif Lutfhansah'); ?>


<?php $__env->startSection('meta'); ?>
  ##parent-placeholder-cb030491157b26a570b6ee91e5b068d99c3b72f6##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('icon'); ?>
  ##parent-placeholder-f8995ba5891b07e328c60d6bd6c10159878c5a13##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
  ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('header'); ?>
  ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('navigation_mobile'); ?>
  ##parent-placeholder-4b28a8eb0a614146837248b960cf305439369d90##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
  ##parent-placeholder-b28b7af69320201d1cf206ebf28373980add1451##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
  ##parent-placeholder-d7eb6b340a11a367a1bec55e4a421d949214759f##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
  ##parent-placeholder-b6e13ad53d8ec41b034c49f131c64e99cf25207a##
<?php $__env->stopSection(); ?>
<?php echo $__env->make('homepage.components.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>